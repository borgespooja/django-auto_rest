from __future__ import unicode_literals

from django.apps import AppConfig


class AutoRestConfig(AppConfig):
    name = 'auto_rest'
